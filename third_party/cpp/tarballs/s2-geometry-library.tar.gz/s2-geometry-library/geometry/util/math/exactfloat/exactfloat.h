// Copyright 2009 Google Inc. All Rights Reserved.
//
// ExactFloat is a multiple-precision floating point type based on the OpenSSL
// Bignum library.  It has the same interface as the built-in "float" and
// "double" types, but only supports the subset of operators and intrinsics
// where it is possible to compute the result exactly.  So for example,
// ExactFloat supports addition and multiplication but not division (since in
// general, the quotient of two floating-point numbers cannot be represented
// exactly).  Exact arithmetic is useful for geometric algorithms, especially
// for disambiguating cases where ordinary double-precision arithmetic yields
// an uncertain result.
//
// ExactFloat is a subset of the faster and more capable MPFloat class (which
// is based on the GNU MPFR library).  The main reason to use this class
// rather than MPFloat is that it is subject to a BSD-style license rather
// than the much restrictive LGPL license.
//
// It has the following features:
//
//  - ExactFloat uses the same syntax as the built-in "float" and "double"
//    types, for example: x += 4 + fabs(2*y*y - z*z).  There are a few
//    differences (see below), but the syntax is compatible enough so that
//    ExactFloat can be used as a template argument to templatized classes
//    such as Vector2, VectorN, Matrix3x3, etc.
//
//  - Results are not rounded; instead, precision is increased so that the
//    result can be represented exactly.  An inexact result is returned only
//    in the case of underflow or overflow (yielding signed zero or infinity
//    respectively), or if the maximum allowed precision is exceeded (yielding
//    NaN).  ExactFloat uses IEEE 754-2008 rules for handling infinities, NaN,
//    rounding to integers, etc.
//
//  - ExactFloat only supports calculations where the result can be
//    represented exactly.  Therefore it supports intrinsics such as fabs()
//    but not transcendentals such as sin(), sqrt(), etc.
//
// Syntax Compatibility with "float" and "double"
// ----------------------------------------------
//
// ExactFloat supports a subset of the operators and intrinsics for the
// built-in "double" type.  (Thus it supports fabs() but not fabsf(), for
// example.)  The syntax is different only in the following cases:
//
//  - Casts and implicit conversions to built-in types (including "bool") are
//    not supported.  So for example, the following will not compile:
//
//      ExactFloat x = 7.5;
//      double y = x;            // ERROR: use x.ToDouble() instead
//      long z = x;              // ERROR: use x.ToDouble() or lround(trunc(x))
//      q = static_cast<int>(x); // ERROR: use x.ToDouble() or lround(trunc(x))
//      if (x) { ... }           // ERROR: use (x != 0) instead
//
//  - The glibc floating-point classification macros (fpclassify, isfinite,
//    isnormal, std::isnan, std::isinf) are not supported.  Instead there are
//    zero-argument methods:
//
//      ExactFloat x;
//      if (std::isnan(x)) { ... }  // ERROR: use (x.is_nan()) instead
//      if (std::isinf(x)) { ... }  // ERROR: use (x.is_inf()) instead
//
// Using ExactFloat with Vector3, etc.
// -----------------------------------
//
// ExactFloat can be used with templatized classes such as Vector2 and Vector3
// (see "util/math/vector3-inl.h"), with the following limitations:
//
//  - Cast() can be used to convert other vector types to an ExactFloat vector
//    type, but not the other way around.  This is because there are no
//    implicit conversions from ExactFloat to built-in types.  You can work
//    around this by calling an explicit conversion method such as
//    ToDouble().  For example:
//
//      typedef Vector3<ExactFloat> Vector3_xf;
//      Vector3_xf x;
//      Vector3_d y;
//      x = Vector3_xf::Cast(y);   // This works.
//      y = Vector3_d::Cast(x);    // This doesn't.
//      y = Vector3_d(x[0].ToDouble(), x[1].ToDouble(), x[2].ToDouble()); // OK
//
//  - IsNaN() is not supported because it calls std::isnan(), which is defined as a
//    macro in <math.h> and therefore can't easily be overrided.
//
// Precision Semantics
// -------------------
//
// Unlike MPFloat, ExactFloat does not allow a maximum precision to be
// specified (it is always unbounded).  Therefore it does not have any of the
// corresponding constructors.
//
// The current precision of an ExactFloat (i.e., the number of bits in its
// mantissa) is returned by prec().  The precision is increased as necessary
// so that the result of every operation can be represented exactly.

#ifndef UTIL_MATH_EXACTFLOAT_EXACTFLOAT_H_
#define UTIL_MATH_EXACTFLOAT_EXACTFLOAT_H_

#include <cmath>
#include <algorithm>

using std::min;
using std::max;
using std::swap;
using std::reverse;
using std::signbit;

#include <string>
using std::string;

#include "base/logging.h"
#include "base/integral_types.h"
#include "openssl/bn.h"
#include "openssl/crypto.h"

// Return the absolute value of a BIGNUM as a 64-bit unsigned integer.
// Requires that BIGNUM fits into 64 bits.
inline static uint64 BN_ext_get_uint64(const BIGNUM* bn) {
  DCHECK_LE(BN_num_bytes(bn), sizeof(uint64));
#if BN_BITS2 == 64
  return BN_get_word(bn);
#else
  COMPILE_ASSERT(BN_BITS2 == 32, at_least_32_bit_openssl_build_needed);
  if (bn->top == 0) return 0;
  if (bn->top == 1) return BN_get_word(bn);
  DCHECK_EQ(bn->top, 2);
  return (static_cast<uint64>(bn->d[1]) << 32) + bn->d[0];
#endif
}

// Count the number of low-order zero bits in the given BIGNUM (ignoring its
// sign).  Returns 0 if the argument is zero.
static int BN_ext_count_low_zero_bits(const BIGNUM* bn) {
  int count = 0;
  for (int i = 0; i < bn->top; ++i) {
    BN_ULONG w = bn->d[i];
    if (w == 0) {
      count += 8 * sizeof(BN_ULONG);
    } else {
      for (; (w & 1) == 0; w >>= 1) {
        ++count;
      }
      break;
    }
  }
  return count;
}

// We define a few simple extensions to the BIGNUM interface.  In some cases
// these depend on BIGNUM internal fields, so they might require tweaking if
// the BIGNUM implementation changes significantly.

// Set a BIGNUM to the given unsigned 64-bit value.
inline static void BN_ext_set_uint64(BIGNUM* bn, uint64 v) {
#if BN_BITS2 == 64
  CHECK(BN_set_word(bn, v));
#else
  COMPILE_ASSERT(BN_BITS2 == 32, at_least_32_bit_openssl_build_needed);
  CHECK(BN_set_word(bn, static_cast<uint32>(v >> 32)));
  CHECK(BN_lshift(bn, bn, 32));
  CHECK(BN_add_word(bn, static_cast<uint32>(v)));
#endif
}

class ExactFloat {
 public:
  // The following limits are imposed by OpenSSL.

  // The maximum exponent supported.  If a value has an exponent larger than
  // this, it is replaced by infinity (with the appropriate sign).
  static const int kMaxExp = 200*1000*1000;  // About 10**(60 million)

  // The minimum exponent supported.  If a value has an exponent less than
  // this, it is replaced by zero (with the appropriate sign).
  static const int kMinExp = -kMaxExp;   // About 10**(-60 million)

  // The maximum number of mantissa bits supported.  If a value has more
  // mantissa bits than this, it is replaced with NaN.  (It is expected that
  // users of this class will never want this much precision.)
  static const int kMaxPrec = 64 << 20;  // About 20 million digits

  // Rounding modes.  kRoundTiesToEven and kRoundTiesAwayFromZero both round
  // to the nearest representable value unless two values are equally close.
  // In that case kRoundTiesToEven rounds to the nearest even value, while
  // kRoundTiesAwayFromZero always rounds away from zero.
  enum RoundingMode {
    kRoundTiesToEven,
    kRoundTiesAwayFromZero,
    kRoundTowardZero,
    kRoundAwayFromZero,
    kRoundTowardPositive,
    kRoundTowardNegative
  };

  /////////////////////////////////////////////////////////////////////////////
  // Constructors

  // The default constructor initializes the value to zero.  (The initial
  // value must be zero rather than NaN for compatibility with the built-in
  // float types.)
  inline ExactFloat();

  // Construct an ExactFloat from a "double".  The constructor is implicit so
  // that this class can be used as a replacement for "float" or "double" in
  // templatized libraries.  (With an explicit constructor, code such as
  // "ExactFloat f = 2.5;" would not compile.)  All double-precision values are
  // supported, including denormalized numbers, infinities, and NaNs.
  ExactFloat(double v){
	  BN_init(&bn_);
	  sign_ = signbit(v) ? -1 : 1;
	  if (std::isnan(v)) {
	    set_nan();
	  } else if (std::isinf(v)) {
	    set_inf(sign_);
	  } else {
	    // The following code is much simpler than messing about with bit masks,
	    // has the advantage of handling denormalized numbers and zero correctly,
	    // and is actually quite efficient (at least compared to the rest of this
	    // code).  "f" is a fraction in the range [0.5, 1), so if we shift it left
	    // by the number of mantissa bits in a double (53, including the leading
	    // "1") then the result is always an integer.
	    int exp;
	    double f = frexp(fabs(v), &exp);
	    uint64 m = static_cast<uint64>(ldexp(f, kDoubleMantissaBits));
	    BN_ext_set_uint64(&bn_, m);
	    bn_exp_ = exp - kDoubleMantissaBits;
	    Canonicalize();
	  }
  };

  // Construct an ExactFloat from an "int".  Note that in general, ints are
  // automatically converted to doubles and so would be handled by the
  // constructor above.  However, the particular argument (0) is ambiguous; the
  // compiler doesn't know whether to treat it as a "double" or "NULL"
  // (invoking the const char* constructor below).
  //
  // We do not provide constructors for "unsigned", "long", "unsigned long",
  // "long long", or "unsigned long long", since these types are not typically
  // used in floating-point calculations and it is safer to require them to be
  // explicitly cast.
  ExactFloat(int v){
	  BN_init(&bn_);
	  sign_ = (v >= 0) ? 1 : -1;
	  // Note that this works even for INT_MIN because the parameter type for
	  // BN_set_word() is unsigned.
	  CHECK(BN_set_word(&bn_, abs(v)));
	  bn_exp_ = 0;
	  Canonicalize();
  };

  // Construct an ExactFloat from a string (such as "1.2e50").  Requires that
  // the value is exactly representable as a floating-point number (so for
  // example, "0.125" is allowed but "0.1" is not).
  explicit ExactFloat(const char* s) { Unimplemented(); }

  // Copy constructor.
  ExactFloat(const ExactFloat& b): sign_(b.sign_), bn_exp_(b.bn_exp_) {BN_init(&bn_); BN_copy(&bn_, &b.bn_);};

  // The destructor is not virtual for efficiency reasons.  Therefore no
  // subclass should declare additional fields that require destruction.
  inline ~ExactFloat();

  /////////////////////////////////////////////////////////////////////
  // Constants
  //
  // As an alternative to the constants below, you can also just use the
  // constants defined in <math.h>, for example:
  //
  //   ExactFloat x = NAN, y = -INFINITY;

  // Return an ExactFloat equal to positive zero (if sign >= 0) or
  // negative zero (if sign < 0).
  static ExactFloat SignedZero(int sign){ExactFloat r; r.set_zero(sign); return r;};

  // Return an ExactFloat equal to positive infinity (if sign >= 0) or
  // negative infinity (if sign < 0).
  static ExactFloat Infinity(int sign){ExactFloat r; r.set_inf(sign); return r;};

  // Return an ExactFloat that is NaN (Not-a-Number).
  static ExactFloat NaN(){ExactFloat r; r.set_nan(); return r;};

  /////////////////////////////////////////////////////////////////////////////
  // Accessor Methods

  // Return the maximum precision of the ExactFloat.  This method exists only
  // for compatibility with MPFloat.
  int max_prec() const { return kMaxPrec; }

  // Return the actual precision of this ExactFloat (the current number of
  // bits in its mantissa).  Returns 0 for non-normal numbers such as NaN.
  int prec() const{return BN_num_bits(&bn_);};

  // Return the exponent of this ExactFloat given that the mantissa is in the
  // range [0.5, 1).  It is an error to call this method if the value is zero,
  // infinity, or NaN.
  int exp() const{DCHECK(is_normal()); return bn_exp_ + BN_num_bits(&bn_);};

  // Set the value of the ExactFloat to +0 (if sign >= 0) or -0 (if sign < 0).
  void set_zero(int sign){sign_ = sign; bn_exp_ = kExpZero; if (!BN_is_zero(&bn_)) BN_zero(&bn_);};

  // Set the value of the ExactFloat to positive infinity (if sign >= 0) or
  // negative infinity (if sign < 0).
  void set_inf(int sign){sign_ = sign; bn_exp_ = kExpInfinity; if (!BN_is_zero(&bn_)) BN_zero(&bn_);};

  // Set the value of the ExactFloat to NaN (Not-a-Number).
  void set_nan(){sign_ = 1; bn_exp_ = kExpNaN; if (!BN_is_zero(&bn_)) BN_zero(&bn_);};

  // Unfortunately, std::isinf(x), std::isnan(x), isnormal(x), and isfinite(x) are
  // defined as macros in <math.h>.  Therefore we can't easily extend them
  // here.  Instead we provide methods with underscores in their names that do
  // the same thing: x.is_inf(), etc.
  //
  // These macros are not implemented: signbit(x), fpclassify(x).

  // Return true if this value is zero (including negative zero).
  inline bool is_zero() const;

  // Return true if this value is infinity (positive or negative).
  inline bool is_inf() const;

  // Return true if this value is NaN (Not-a-Number).
  inline bool is_nan() const;

  // Return true if this value is a normal floating-point number.  Non-normal
  // values (zero, infinity, and NaN) often need to be handled separately
  // because they are represented using special exponent values and their
  // mantissa is not defined.
  inline bool is_normal() const;

  // Return true if this value is a normal floating-point number or zero,
  // i.e. it is not infinity or NaN.
  inline bool is_finite() const;

  // Return true if the sign bit is set (this includes negative zero).
  inline bool sign_bit() const;

  // Return +1 if this ExactFloat is positive, -1 if it is negative, and 0
  // if it is zero or NaN.  Note that unlike sign_bit(), sgn() returns 0 for
  // both positive and negative zero.
  inline int sgn() const;

  /////////////////////////////////////////////////////////////////////////////
  // Conversion Methods
  //
  // Note that some conversions are defined as functions further below,
  // e.g. to convert to an integer you can use lround(), llrint(), etc.

  // Round to double precision.  Note that since doubles have a much smaller
  // exponent range than ExactFloats, very small values may be rounded to
  // (positive or negative) zero, and very large values may be rounded to
  // infinity.
  //
  // It is very important to make this a named method rather than an implicit
  // conversion, because otherwise there would be a silent loss of precision
  // whenever some desired operator or function happens not to be implemented.
  // For example, if fabs() were not implemented and "x" and "y" were
  // ExactFloats, then x = fabs(y) would silently convert "y" to a "double",
  // take its absolute value, and convert it back to an ExactFloat.
  double ToDouble() const;

  // Return a human-readable string such that if two values with the same
  // precision are different, then their string representations are different.
  // The format is similar to printf("%g"), except that the number of
  // significant digits depends on the precision (with a minimum of 10).
  // Trailing zeros are stripped (just like "%g").
  //
  // Note that if two values have different precisions, they may have the same
  // ToString() value even though their values are slightly different.  If you
  // need to distinguish such values, use ToUniqueString() intead.
  string ToString() const;

  // Return a string formatted according to printf("%Ng") where N is the given
  // maximum number of significant digits.
  string ToStringWithMaxDigits(int max_digits) const;

  // Return a human-readable string such that if two ExactFloats have different
  // values, then their string representations are always different.  This
  // method is useful for debugging.  The string has the form "value<prec>",
  // where "prec" is the actual precision of the ExactFloat (e.g., "0.215<50>").
  string ToUniqueString() const;

  // Return an upper bound on the number of significant digits required to
  // distinguish any two floating-point numbers with the given precision when
  // they are formatted as decimal strings in exponential format.
  static int NumSignificantDigitsForPrec(int prec);

  // Output the ExactFloat in human-readable format, e.g. for logging.
  friend ostream& operator<<(ostream& o, ExactFloat const& f) {
    return o << f.ToString();
  }

  /////////////////////////////////////////////////////////////////////////////
  // Other Methods

  // Round the ExactFloat so that its mantissa has at most "max_prec" bits
  // using the given rounding mode.  Requires "max_prec" to be at least 2
  // (since kRoundTiesToEven doesn't make sense with fewer bits than this).
  ExactFloat RoundToMaxPrec(int max_prec, RoundingMode mode) const;

  /////////////////////////////////////////////////////////////////////////////
  // Operators

  // Assignment operator.
  ExactFloat& operator=(const ExactFloat& b){
	  if (this != &b) {
	    sign_ = b.sign_;
	    bn_exp_ = b.bn_exp_;
	    BN_copy(&bn_, &b.bn_);
	  }
	  return *this;
  };

  // Unary plus.
  ExactFloat operator+() const { return *this; }

  // Unary minus.
  ExactFloat operator-() const{return CopyWithSign(-sign_);};

  // Addition.
  friend ExactFloat operator+(const ExactFloat& a, const ExactFloat& b);

  // Subtraction.
  friend ExactFloat operator-(const ExactFloat& a, const ExactFloat& b);

  // Multiplication.
  friend ExactFloat operator*(const ExactFloat& a, const ExactFloat& b);

  // Division is not implemented because the result cannot be represented
  // exactly in general.  Doing this properly would require extending all the
  // operations to support rounding to a specified precision.

  // Arithmetic assignment operators (+=, -=, *=).
  //ExactFloat& operator+=(const ExactFloat& b) { return (*this = *this + b); }
  //ExactFloat& operator-=(const ExactFloat& b) { return (*this = *this - b); }
  //ExactFloat& operator*=(const ExactFloat& b) { return (*this = *this * b); }

  // Comparison operators (==, !=, <, <=, >, >=).
  friend bool operator==(const ExactFloat& a, const ExactFloat& b);
  friend bool operator<(const ExactFloat& a, const ExactFloat& b);
  // These don't need to be friends but are declared here for completeness.
  inline friend bool operator!=(const ExactFloat& a, const ExactFloat& b);
  inline friend bool operator<=(const ExactFloat& a, const ExactFloat& b);
  inline friend bool operator>(const ExactFloat& a, const ExactFloat& b);
  inline friend bool operator>=(const ExactFloat& a, const ExactFloat& b);

  /////////////////////////////////////////////////////////////////////
  // Math Intrinsics
  //
  // The math intrinsics currently supported by ExactFloat are listed below.
  // Except as noted, they behave identically to the usual glibc intrinsics
  // except that they have greater precision.  See the man pages for more
  // information.

  //////// Miscellaneous simple arithmetic functions.

  // Absolute value.
  friend ExactFloat fabs(const ExactFloat& a);

  // Maximum of two values.
  friend ExactFloat fmax(const ExactFloat& a, const ExactFloat& b);

  // Minimum of two values.
  friend ExactFloat fmin(const ExactFloat& a, const ExactFloat& b);

  // Positive difference: max(a - b, 0).
  friend ExactFloat fdim(const ExactFloat& a, const ExactFloat& b);

  //////// Integer rounding functions that return ExactFloat values.

  // Round up to the nearest integer.
  friend ExactFloat ceil(const ExactFloat& a);

  // Round down to the nearest integer.
  friend ExactFloat floor(const ExactFloat& a);

  // Round to the nearest integer not larger in absolute value.
  // For example: f(-1.9) = -1, f(2.9) = 2.
  friend ExactFloat trunc(const ExactFloat& a);

  // Round to the nearest integer, rounding halfway cases away from zero.
  // For example: f(-0.5) = -1, f(0.5) = 1, f(1.5) = 2, f(2.5) = 3.
  friend ExactFloat round(const ExactFloat& a);

  // Round to the nearest integer, rounding halfway cases to an even integer.
  // For example: f(-0.5) = 0, f(0.5) = 0, f(1.5) = 2, f(2.5) = 2.
  friend ExactFloat rint(const ExactFloat& a);

  // A synonym for rint().
  friend ExactFloat nearbyint(const ExactFloat& a) { return rint(a); }

  //////// Integer rounding functions that return C++ integer types.

  // Like rint(), but rounds to the nearest "long" value.  Returns the
  // minimum/maximum possible integer if the value is out of range.
  friend long lrint(const ExactFloat& a);

  // Like rint(), but rounds to the nearest "long long" value.  Returns the
  // minimum/maximum possible integer if the value is out of range.
  friend long long llrint(const ExactFloat& a);

  // Like round(), but rounds to the nearest "long" value.  Returns the
  // minimum/maximum possible integer if the value is out of range.
  friend long lround(const ExactFloat& a);

  // Like round(), but rounds to the nearest "long long" value.  Returns the
  // minimum/maximum possible integer if the value is out of range.
  friend long long llround(const ExactFloat& a);

  //////// Remainder functions.

  // The remainder of dividing "a" by "b", where the quotient is rounded toward
  // zero to the nearest integer.  Similar to (a - trunc(a / b) * b).
  friend ExactFloat fmod(const ExactFloat& a, const ExactFloat& b) {
    // Note that it is possible to implement this operation exactly, it just
    // hasn't been done.
    return Unimplemented();
  }

  // The remainder of dividing "a" by "b", where the quotient is rounded to the
  // nearest integer, rounding halfway cases to an even integer.  Similar to
  // (a - rint(a / b) * b).
  friend ExactFloat remainder(const ExactFloat& a, const ExactFloat& b) {
    // Note that it is possible to implement this operation exactly, it just
    // hasn't been done.
    return Unimplemented();
  }

  // A synonym for remainder().
  friend ExactFloat drem(const ExactFloat& a, const ExactFloat& b) {
    return remainder(a, b);
  }

  // Break the argument "a" into integer and fractional parts, each of which
  // has the same sign as "a".  The fractional part is returned, and the
  // integer part is stored in the output parameter "i_ptr".  Both output
  // values are set to have the same maximum precision as "a".
  friend ExactFloat modf(const ExactFloat& a, ExactFloat* i_ptr) {
    // Note that it is possible to implement this operation exactly, it just
    // hasn't been done.
    return Unimplemented();
  }

  //////// Floating-point manipulation functions.

  // Return an ExactFloat with the magnitude of "a" and the sign bit of "b".
  // (Note that an IEEE zero can be either positive or negative.)
  friend ExactFloat copysign(const ExactFloat& a, const ExactFloat& b);

  // Convert "a" to a normalized fraction in the range [0.5, 1) times a power
  // of two.  Return the fraction and set "exp" to the exponent.  If "a" is
  // zero, infinity, or NaN then return "a" and set "exp" to zero.
  friend ExactFloat frexp(const ExactFloat& a, int* exp);

  // Return "a" multiplied by 2 raised to the power "exp".
  friend ExactFloat ldexp(const ExactFloat& a, int exp);

  // A synonym for ldexp().
  friend ExactFloat scalbn(const ExactFloat& a, int exp) {
    return ldexp(a, exp);
  }

  // A version of ldexp() where "exp" is a long integer.
  friend ExactFloat scalbln(const ExactFloat& a, long exp) {
    return ldexp(a, exp);
  }

  // Convert "a" to a normalized fraction in the range [1,2) times a power of
  // two, and return the exponent value as an integer.  This is equivalent to
  // lrint(floor(log2(fabs(a)))) but it is computed more efficiently.  Returns
  // the constants documented in the man page for zero, infinity, or NaN.
  friend int ilogb(const ExactFloat& a);

  // Convert "a" to a normalized fraction in the range [1,2) times a power of
  // two, and return the exponent value as an ExactFloat.  This is equivalent to
  // floor(log2(fabs(a))) but it is computed more efficiently.
  friend ExactFloat logb(const ExactFloat& a);

 protected:
  // Non-normal numbers are represented using special exponent values and a
  // mantissa of zero.  Do not change these values; methods such as
  // is_normal() make assumptions about their ordering.  Non-normal numbers
  // can have either a positive or negative sign (including zero and NaN).
  static const int32 kExpNaN = INT_MAX;
  static const int32 kExpInfinity = INT_MAX - 1;
  static const int32 kExpZero = INT_MAX - 2;

  // Normal numbers are represented as (sign_ * bn_ * (2 ** bn_exp_)), where:
  //  - sign_ is either +1 or -1
  //  - bn_ is a BIGNUM with a positive value
  //  - bn_exp_ is the base-2 exponent applied to bn_.
  int32 sign_;
  int32 bn_exp_;
  BIGNUM bn_;

  // A standard IEEE "double" has a 53-bit mantissa consisting of a 52-bit
  // fraction plus an implicit leading "1" bit.
  static const int kDoubleMantissaBits = 53;

  // Convert an ExactFloat with no more than 53 bits in its mantissa to a
  // "double".  This method handles non-normal values (NaN, etc).
  double ToDoubleHelper() const;

  // Round an ExactFloat so that it is a multiple of (2 ** bit_exp), using the
  // given rounding mode.
  ExactFloat RoundToPowerOf2(int bit_exp, RoundingMode mode) const;

  // Convert the ExactFloat to a decimal value of the form 0.ddd * (10 ** x),
  // with at most "max_digits" significant digits (trailing zeros are removed).
  // Set (*digits) to the ASCII digits and return the decimal exponent "x".
  int GetDecimalDigits(int max_digits, string* digits) const;

  // Return a_sign * fabs(a) + b_sign * fabs(b).  Used to implement addition
  // and subtraction.
  static ExactFloat SignedSum(int a_sign, const ExactFloat* a,
                              int b_sign, const ExactFloat* b){
	  if (!a->is_normal() || !b->is_normal()) {
	    // Handle zero, infinity, and NaN according to IEEE 754-2008.
	    if (a->is_nan()) return *a;
	    if (b->is_nan()) return *b;
	    if (a->is_inf()) {
	      // Adding two infinities with opposite sign yields NaN.
	      if (b->is_inf() && a_sign != b_sign) return NaN();
	      return Infinity(a_sign);
	    }
	    if (b->is_inf()) return Infinity(b_sign);
	    if (a->is_zero()) {
	      if (!b->is_zero()) return b->CopyWithSign(b_sign);
	      // Adding two zeros with the same sign preserves the sign.
	      if (a_sign == b_sign) return SignedZero(a_sign);
	      // Adding two zeros of opposite sign produces +0.
	      return SignedZero(+1);
	    }
	    DCHECK(b->is_zero());
	    return a->CopyWithSign(a_sign);
	  }
	  // Swap the numbers if necessary so that "a" has the larger bn_exp_.
	  if (a->bn_exp_ < b->bn_exp_) {
	    swap(a_sign, b_sign);
	    swap(a, b);
	  }
	  // Shift "a" if necessary so that both values have the same bn_exp_.
	  ExactFloat r;
	  if (a->bn_exp_ > b->bn_exp_) {
	    CHECK(BN_lshift(&r.bn_, &a->bn_, a->bn_exp_ - b->bn_exp_));
	    a = &r;  // The only field of "a" used below is bn_.
	  }
	  r.bn_exp_ = b->bn_exp_;
	  if (a_sign == b_sign) {
	    CHECK(BN_add(&r.bn_, &a->bn_, &b->bn_));
	    r.sign_ = a_sign;
	  } else {
	    // Note that the BIGNUM documentation is out of date -- all methods now
	    // allow the result to be the same as any input argument, so it is okay if
	    // (a == &r) due to the shift above.
	    CHECK(BN_sub(&r.bn_, &a->bn_, &b->bn_));
	    if (BN_is_zero(&r.bn_)) {
	      r.sign_ = +1;
	    } else if (BN_is_negative(&r.bn_)) {
	      // The magnitude of "b" was larger.
	      r.sign_ = b_sign;
	      BN_set_negative(&r.bn_, false);
	    } else {
	      // They were equal, or the magnitude of "a" was larger.
	      r.sign_ = a_sign;
	    }
	  }
	  r.Canonicalize();
	  return r;
  };

  // Convert an ExactFloat to its canonical form.  Underflow results in signed
  // zero, overflow results in signed infinity, and precision overflow results
  // in NaN.  A zero mantissa is converted to the canonical zero value with
  // the given sign; otherwise the mantissa is normalized so that its low bit
  // is 1.  Non-normal numbers are left unchanged.
  void Canonicalize(){
	  if (!is_normal()) return;

	  // Underflow/overflow occurs if exp() is not in [kMinExp, kMaxExp].
	  // We also convert a zero mantissa to signed zero.
	  int my_exp = exp();
	  if (my_exp < kMinExp || BN_is_zero(&bn_)) {
	    set_zero(sign_);
	  } else if (my_exp > kMaxExp) {
	    set_inf(sign_);
	  } else if (!BN_is_odd(&bn_)) {
	    // Remove any low-order zero bits from the mantissa.
	    DCHECK(!BN_is_zero(&bn_));
	    int shift = BN_ext_count_low_zero_bits(&bn_);
	    if (shift > 0) {
	      CHECK(BN_rshift(&bn_, &bn_, shift));
	      bn_exp_ += shift;
	    }
	  }
	  // If the mantissa has too many bits, we replace it by NaN to indicate
	  // that an inexact calculation has occurred.
	  if (prec() > kMaxPrec) {
	    set_nan();
	  }
  };

  // Scale the mantissa of this ExactFloat so that it has the same bn_exp_ as
  // "b", then return -1, 0, or 1 according to whether the scaled mantissa is
  // less, equal, or greater than the mantissa of "b".  Requires that both
  // values are normal.
  int ScaleAndCompare(const ExactFloat& b) const;

  // Return true if the magnitude of this ExactFloat is less than the
  // magnitude of "b".  Requires that neither value is NaN.
  bool UnsignedLess(const ExactFloat& b) const;

  // Return an ExactFloat with the magnitude of this ExactFloat and the given
  // sign.  (Similar to copysign, except that the sign is given explicitly
  // rather than being copied from another ExactFloat.)
  inline ExactFloat CopyWithSign(int sign) const;

  // Convert an ExactFloat to an integer of type "T" using the given rounding
  // mode.  The type "T" must be signed.  Returns the largest possible integer
  // for NaN, and clamps out of range values to the largest or smallest
  // possible values.
  template <class T> T ToInteger(RoundingMode mode) const;

  // Log a fatal error message (used for unimplemented methods).
  static ExactFloat Unimplemented();
};

// Define storage for constants.
const int ExactFloat::kMinExp;
const int ExactFloat::kMaxExp;
const int ExactFloat::kMaxPrec;
const int32 ExactFloat::kExpNaN;
const int32 ExactFloat::kExpInfinity;
const int32 ExactFloat::kExpZero;
const int ExactFloat::kDoubleMantissaBits;

// To simplify the overflow/underflow logic, we limit the exponent and
// precision range so that (2 * bn_exp_) does not overflow an "int".  We take
// advantage of this, for example, by only checking for overflow/underflow
// *after* multiplying two numbers.
COMPILE_ASSERT(
    ExactFloat::kMaxExp <= INT_MAX / 2 &&
    ExactFloat::kMinExp - ExactFloat::kMaxPrec >= INT_MIN / 2,
    exactfloat_exponent_might_overflow);

/////////////////////////////////////////////////////////////////////////
// Implementation details follow:

inline ExactFloat::ExactFloat() : sign_(1), bn_exp_(kExpZero) {
  BN_init(&bn_);
}

inline ExactFloat::~ExactFloat() {
  BN_free(&bn_);
}

inline bool ExactFloat::is_zero() const { return bn_exp_ == kExpZero; }
inline bool ExactFloat::is_inf() const { return bn_exp_ == kExpInfinity; }
inline bool ExactFloat::is_nan() const { return bn_exp_ == kExpNaN; }
inline bool ExactFloat::is_normal() const { return bn_exp_ < kExpZero; }
inline bool ExactFloat::is_finite() const { return bn_exp_ <= kExpZero; }
inline bool ExactFloat::sign_bit() const { return sign_ < 0; }

inline int ExactFloat::sgn() const {
  return (is_nan() || is_zero()) ? 0 : sign_;
}

inline bool operator!=(const ExactFloat& a, const ExactFloat& b) {
  return !(a == b);
}

inline bool operator<=(const ExactFloat& a, const ExactFloat& b) {
  // NaN is unordered compared to everything, including itself.
  if (a.is_nan() || b.is_nan()) return false;
  return !(b < a);
}

inline bool operator>(const ExactFloat& a, const ExactFloat& b) {
  return b < a;
}

inline bool operator>=(const ExactFloat& a, const ExactFloat& b) {
  return b <= a;
}

inline ExactFloat ExactFloat::CopyWithSign(int sign) const {
  ExactFloat r = *this;
  r.sign_ = sign;
  return r;
}

ExactFloat operator+(const ExactFloat& a, const ExactFloat& b) {
  return ExactFloat::SignedSum(a.sign_, &a, b.sign_, &b);
}

ExactFloat operator-(const ExactFloat& a, const ExactFloat& b) {
  return ExactFloat::SignedSum(a.sign_, &a, -b.sign_, &b);
}


ExactFloat operator*(const ExactFloat& a, const ExactFloat& b) {
  int result_sign = a.sign_ * b.sign_;
  if (!a.is_normal() || !b.is_normal()) {
    // Handle zero, infinity, and NaN according to IEEE 754-2008.
    if (a.is_nan()) return a;
    if (b.is_nan()) return b;
    if (a.is_inf()) {
      // Infinity times zero yields NaN.
      if (b.is_zero()) return ExactFloat::NaN();
      return ExactFloat::Infinity(result_sign);
    }
    if (b.is_inf()) {
      if (a.is_zero()) return ExactFloat::NaN();
      return ExactFloat::Infinity(result_sign);
    }
    DCHECK(a.is_zero() || b.is_zero());
    return ExactFloat::SignedZero(result_sign);
  }
  ExactFloat r;
  r.sign_ = result_sign;
  r.bn_exp_ = a.bn_exp_ + b.bn_exp_;
  BN_CTX* ctx = BN_CTX_new();
  CHECK(BN_mul(&r.bn_, &a.bn_, &b.bn_, ctx));
  BN_CTX_free(ctx);
  r.Canonicalize();
  return r;
}
#endif  // UTIL_MATH_EXACTFLOAT_EXACTFLOAT_H_
