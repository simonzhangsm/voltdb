var searchData=
[
  ['empty_5fstruct',['empty_struct',['../a00013.html',1,'stx::btree_set']]],
  ['empty_5fstruct',['empty_struct',['../a00014.html',1,'stx::btree_multiset']]]
];
