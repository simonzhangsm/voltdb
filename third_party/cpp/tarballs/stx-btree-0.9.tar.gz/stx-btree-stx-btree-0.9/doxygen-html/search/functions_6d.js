var searchData=
[
  ['max_5fsize',['max_size',['../a00001.html#a3285e41cd6c4566e99d8c82803ad4d92',1,'stx::btree::max_size()'],['../a00004.html#ae0655211e7a2c51312cfaf7b4cd87836',1,'stx::btree_map::max_size()'],['../a00005.html#a122b57700263111abc6d8740123e2480',1,'stx::btree_multimap::max_size()'],['../a00006.html#a2b0012b20d4bc04d78d1297d78550d8a',1,'stx::btree_multiset::max_size()'],['../a00009.html#ae3338e9685da6924c7be74906b3cf68b',1,'stx::btree_set::max_size()']]],
  ['merge_5finner',['merge_inner',['../a00001.html#ae41ed6372b1f0e7cc76d082fb7d0c18c',1,'stx::btree']]],
  ['merge_5fleaves',['merge_leaves',['../a00001.html#a8fde1571d49bf44f58f492ccad6875f9',1,'stx::btree']]]
];
