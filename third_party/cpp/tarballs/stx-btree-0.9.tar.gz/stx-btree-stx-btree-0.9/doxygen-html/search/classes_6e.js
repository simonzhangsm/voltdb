var searchData=
[
  ['node',['node',['../a00018.html',1,'stx::btree']]]
];
