var searchData=
[
  ['allocate_5finner',['allocate_inner',['../a00001.html#a1bf04093f2dc2a1cb57955ff55d3762a',1,'stx::btree']]],
  ['allocate_5fleaf',['allocate_leaf',['../a00001.html#ab6ff4b0f13f48e417a45431318a00337',1,'stx::btree']]],
  ['avgfill_5fleaves',['avgfill_leaves',['../a00021.html#a9988e57cfa46a77f0bc02f67faab2d1f',1,'stx::btree::tree_stats']]]
];
