var searchData=
[
  ['nodes',['nodes',['../a00021.html#adf69b8f2b4df771fc5b1bd4e248a7a47',1,'stx::btree::tree_stats']]]
];
