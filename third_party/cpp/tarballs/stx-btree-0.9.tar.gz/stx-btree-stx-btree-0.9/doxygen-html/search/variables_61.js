var searchData=
[
  ['allow_5fduplicates',['allow_duplicates',['../a00001.html#acd41575a35d1c5d55e955aafc9762454',1,'stx::btree::allow_duplicates()'],['../a00012.html#a6c34468093568a6008699cf81e489cc4',1,'stx::btree::dump_header::allow_duplicates()'],['../a00004.html#a7a93d908ea2b967d4a54946a37675e25',1,'stx::btree_map::allow_duplicates()'],['../a00005.html#abdf2f0d71029020565eb3c9df2a71db6',1,'stx::btree_multimap::allow_duplicates()'],['../a00006.html#a2a11e2ee03e9bb4cb206826de0b135b2',1,'stx::btree_multiset::allow_duplicates()'],['../a00009.html#a76a14434ee750af9999bea4e2b657b36',1,'stx::btree_set::allow_duplicates()']]]
];
